#!/bin/bash

# Menu de ayuda donde los usuarios pueden seleccionar opciones
if [ "$1" = "-help" ]; then
    opcion=0 #seteamos la var opcion en 0 

    while [ "$opcion" != 4 ] #mientras var opcion sea distinto de 4 entra
    do
        clear #para limpiar la terminal
        echo "=================================="
        echo "        MENU DE AYUDA"
        echo "=================================="
        echo "1 - Uso del script"
        echo "2 - Ejemplos"
        echo "3 - Descripcion de parametros"
        echo "4 - Salir"
        echo "=================================="

        read -p "Seleccione una opcion: " opcion #pedimos al usuario la opcion que quiere.

        case $opcion in

            1)
                echo ""
                echo "Uso:"
                echo "./backup_full.sh <origen> <destino>"
                read -p "Presione ENTER para continuar..."
                ;;

            2)
                echo ""
                echo "Ejemplos:"
                echo "./backup_full.sh /var/log /backup_dir"
                echo "./backup_full.sh /www_dir /backup_dir"
                read -p "Presione ENTER para continuar..."
                ;;

            3)
                echo ""
                echo "Parametros:"
                echo "Origen  : Directorio a respaldar."
                echo "Destino : Directorio donde se guardara el backup."
                read -p "Presione ENTER para continuar..."
                ;;

            4)
                echo "Saliendo..."
                ;;

            *)
                echo "Opcion incorrecta."
		;;
        esac

    done

    exit 0
fi

ORIGEN=$1 #guardamos en una var el parametro 1
DESTINO=$2 # lo mismo con el parametro 2

# Validamos que el directorio origen exista, y si no le pedimos que lo ingrese nuevamente
while [ ! -d "$ORIGEN" ]
do
    echo "El directorio origen '$ORIGEN' no existe."
    read -p "Ingrese un directorio origen válido: " ORIGEN
done

# Validamos que el directorio destino exista, y si no le pedimos que lo ingrese nuevamente
while [ ! -d "$DESTINO" ]
do
    echo "El directorio destino '$DESTINO' no existe."
    read -p "Ingrese un directorio destino válido: " DESTINO
done

FECHA=$(date +%Y%m%d) # guardamos la fecha actual seteandola en ANSI
NOMBRE=$(echo "$ORIGEN" | grep -o '[^/]\+$') # con redireccion, mandamos la salida del echo a grep con las opciones que m con -o solo la coincidencia ademas como filtro le indicamos con [^/] cualquier caracter que no sea /, \+ uno o mas y $ final de la linea.

tar -czf "$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz" "$ORIGEN" #comprimimos el archivo con el nombre pedido

#verificamos que la compresion no haya tenido ningun error con $? y mostramos el mensaje correspondiente
if [ $? -eq 0 ]; then
    echo "Backup realizado correctamente:"
    echo "$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz"
else
    echo "Error al generar el backup."
fi
