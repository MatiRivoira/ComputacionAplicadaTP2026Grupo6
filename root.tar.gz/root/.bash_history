rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
clr
clear
loadkeys us
clear
cat /etc/default/keyboard
dpkg-reconfigure keyboard-configuration
CLEAR
dpkg-reconfigure keyboard-configuration
clr
clear
dpkg-reconfigure keyboard-configuration
clear
loadkeys us
cat /etc/default/keyboard
service keyboard-setup restart
reboot
clear
hostname
clear
nano /etc/hostname
ls
cd
ls -l
nano /etc/hostname
pwd
ps -p 1
clear
vi /etc/hostname
clear
nano --version
which nano
dpkg -l nano
clear
apt update
clear
apt install nano
apt update
clear
ip a
visudo 
clear
clear
ipconfig
clear
vi /etc/network/interfaces
clear
hostname
clear
hostname TPServer
hostname
vi /etc/hostname
clear
hostname
clear
cat /etc/hostname
clear
echo TPServer > /etc/hostname
reboot 
clear
cat /etc/hostname
clear
cat /etc/network/interfaces
vi /etc/network/interfaces
clear
vi /etc/network/interfaces
clear
vi /etc/network/interfaces
vi /etc/network/interfaces
clear
vi /etc/network/interfaces
claer
clear
vi /etc/network/interfaces
vi /etc/network/interfaces
vi /etc/network/interfaces
clear
vi /etc/network/interfaces
lear
clear
vi /etc/network/interfaces
vi /etc/network/interfaces
clear
ip a
cat /etc/network/interfaces
systemctl restart networking
ip a
clear
ip a
cat /etc/network/interfaces
clear
cat /etc/network/interfaces
vi /etc/network/interfaces\
vi /etc/network/interfaces
clear
vi /etc/network/interfaces
clear
vi /etc/network/interfaces
reboot
clear
ip a
ping 192.168.1.1
clear
vi /etc/network/interfaces
clear
clear
fdisk -l
clear
fdisk -l
clear
fdisk /dev/sda
clear
fdisk
fdisk /dev/sda
fdisk -l
ls
\\
clear
lsblk
clear
fdisk /dev/sdc
fdisk /dev/sdc
clear
fdisk /dev/sdc
clear
lsblk
fdisk /dev/sdc
clear
fdisk /dev/sdc
clear
lsblk
fdisk /dev/sdc
lsblk
clear
lsblk
mkdir /www_dir
lsblk
clear
m
clear
mkdir /backup_dir
ls -l
cd /www_dir
ls/l
ls -l
clear
cd
clear
blkid
vi /etc/fstab
clear
mount -a
vi /etc/fstab
clear
mount -a
lsblk
mount /dev/sdc1 /www_dir
lsblk -f
clear
mkfs.ext4 /dev/sdc1
mount /dev/sdc1 /www_dir
mkfs.ext4 /dev/sdc2
lsblk -f
clear
mkfs.ext4 /dev/sdc1
clear
mkfs.ext4 /dev/sdc2
clear
mkfs.ext4 /dev/sdc2
mkfs.ext4 /dev/sdc1
clear
lsblk
lsblk -f
reboot
clear
lsblk -f
lsblk
clear
fdisk /dev/sdc
clear
fdisk /dev/sdc
reboot
clear
lsblk
clear
fdisk /dev/sdc
CLEAR
clear
fdisk /dev/sdc
lsblk
reboot
clear
lsblk
clear
vi /etc/fstab
clear
vi /etc/fstab
clear
cat /proc/partitions
cd /proc
ls -l
cd
cd /proc/partitions
cat /proc/partitions
clear
cat /proc/partitions > /opt/particion
cat /opt/particion
clear
apt update
cat /etc/os-release
clear
apt update
ping -c 4 8.8.8.8
clear
clear
vi /etc/apt/sources.list
clear
ip a
clear
vi /etc/apt/sources.list
apt update
clear
vi /etc/apt/sources.list
clear
apt update
clear
apt upgrade
clear
cceasdas
reboot
clear
cat /etc/os-release
apt update
apt upgrade
cat /etc/os-release
clear
cat /etc/os-release
clear
apt update
clear
apt install openssh-server
clear
clear
system status ssh
systemctl status ssh
clear
systemctl status ssh
clear
ssh-keygen -t rsa -b 4096
clear
cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys
,clear
clear
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
clear
vi /etc/ssh/sshd_config
clear
systemctl restart ssh
systemctl status ssh
ls -la /root/.ssh
vi /etc/ssh/sshd_config
clear
reboot
clear
passwd
clear
passwd
reboot
clear
passwd
passwd
clear
grep PermitRootLogin /etc/ssg/ssgd_config
grep PermitRootLogin /etc/ssh/ssgd_config
grep PermitRootLogin /etc/ssh/sshd_config
vi /etc/ssh/sshd_config
clear
reboot
clear
clear
apt update
clear
apt install apache2
clear
apt install php libapache2-mod-php
clear
apache2 -v
php -v
clear
systemctl staqtus apache2
systemctl status apache2
clear
cp /root/index.php /www_dir/
cd
ls -l
cd ?
cd /
clear
ls -l
cd /root
ls -l
tar -tzf /root/Material_Adicional_TPVMCA.tar.gz
clear
tar -tzf /root/Material_Adicional_TPVMCA.tar.gz
clear
cd
ls
ls -l
clear
tar -xzvf /root/Material_Adicional_TPVMCA.tar.gz -C /root
cd
ls
cd /material_adicional_tpvmca
cd /Material_Adicional_TPVMCA
cd ls-
cd
clear
ls -l
clear
ls
cd Material_Adicional_TPVMCA
ls
clear
cd 
mv Material_Adicional_TPVMCA Archivos
ls
clear
clear
cp /root/archivos/index.php /www_dir
ls
cp /root/Archivos/index.php /www_dir
CLEAR
clear
cp /root/Archivos/index.php /www_dir
cp /root/Archivos/logo.png /www_dir
ls -l /www_dir
clear
vi /etc/apache2/sites-available/000-default.conf
clear
vi /etc/apache2/apache2.conf
clear
vi /etc/apache2/apache2.conf
clear
reboot
clear
systemctl status apache2
cleaer
clear
vi /etc/apache2/apache2.conf
clear
systemctl status apache2
reboot
clear
systemctl status apache2
clear
systemctl status apache2
clear
ip a
clear
apt update
clear
apt install mariadb-server
systemctl status mariadb
clear
systemctl status mariadb
clear
mysql -u root
clear
mysql -u root
clear
mysql -u root\
mysql -u root\
mysql -u root
clear
mysql -u root empresa < /root/Archivos/db.sql
clear
mysql -u root
clear
cd /www_dir
ls
clear
cd
cd /opt/scripts
cd /opt
ls
clear
mkdir -p /opt/scripts
touch /opt/scripts/backup_full.sh
cd scripts
ls
clear
vi /opt/scripts/backup_full.sh
cat /opt/scripts/backup_full.sh
vi /opt/scripts/backup_full.sh
clear
cat /opt/scripts/backup_full.sh
vi /opt/scripts/backup_full.sh
cat /opt/scripts/backup_full.sh
vi /opt/scripts/backup_full.sh
clear
ls
backup_full.sh
clear
cd
clear
chmod +x /opt/scripts/backup_full.sh
ls /opt/scripts/backup_full.sh
ls -l /opt/scripts/backup_full.sh
clear
/opt/scripts/backup_full.sh
clear
/opt/scripts/backup_full.sh -help
clear
/opt/scripts/backup_full.sh \
clear
/opt/scripts/backup_full.sh \
clear
/opt/scripts/backup_full.sh -help
d

d
clear
vi /opt/scripts/backup_full.sh
clear
/opt/scripts/backup_full.sh -help
clear
/opt/scripts/backup_full.sh -help
clear
vi /opt/scripts/backup_full.sh
clear
/opt/scripts/backup_full.sh -help
vi /opt/scripts/backup_full.sh
clear
/opt/scripts/backup_full.sh -help
clear
vi /opt/scripts/backup_full.sh\
vi /opt/scripts/backup_full.sh
clear
/opt/scripts/backup_full.sh -help
clear
vi /opt/scripts/backup_full.sh
clear
/opt/scripts/backup_full.sh -help
clear
echo "Prueba de backup" > /www_dir/test.txt
ls -l /www_dir
/opt/scripts/backup_full.sh /www_dir /backup_dir
ls -lh /backup_dir
tar -tzf /backup_dir/www_dir_bkp_20260614.tar.gz
clear
/opt/scripts/backup_full.sh /www_dir /backup_dir
tar -tzf /backup_dir/www_dir_bkp_20260614.tar.gz
clear
crontab -e
clear
crontab -l
clear
apt update
apt install git -y
clear
git config --global user.name "Tu Nombre"
git config --global user.email "mgrivoira26@gmail.com"
git init
git add .
git commit -m "Entrega TP Linux"
clear
clear
mkdir -p /media/entrega
clear
tar -czvf /media/entrega/root.tar.gz /root
tar -czvf /media/entrega/etc.tar.gz /etc
tar -czvf /media/entrega/opt.tar.gz /opt
tar -czvf /media/entrega/www_dir.tar.gz /www_dir
tar -czvf /media/entrega/backup_dir.tar.gz /backup_dir
clear
clear
clear
ls -lh /media/entrega
clear
scp root@192.168.1.51:/media/entrega/*.tar.gz C:\Users\Matias\Desktop\
scp -r root@IP_DEBIAN:/media/* C:\Users\Matias\Desktop\
scp -r root@IP_DEBIAN:/media/* C:\Users\Matias\Desktop\
scp -r root@IP_DEBIAN:/media/* C:\Users\nurmati\Desktop\
scp -r root@192.168.1.250:/media/* C:\Users\nurmati\Desktop\
scp -r root@192.168.1.250:/media/* C:\Users\nurmati\Desktop\
scp -r root@192.168.1.250:/media/* C:\usuarios\nurmati\Desktop\
scp -r root@192.168.1.250:/media/* C:\
scp -r root@192.168.1.250:/media/* C:\Users\nurmati
scp -r root@192.168.1.250:/media C:\Users\nurmati
clear
clear
ssh root@192.268.1.250
ssh 192.268.1.250@root
ssh root@192.268.1.250
